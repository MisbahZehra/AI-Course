from flask import Flask, render_template

app = Flask(__name__, template_folder='Template')

# Dummy data for blog posts
posts = [
    {"id": 1, "title": "Introduction to Flask", "summary": "Learn how Flask works with this beginner's guide."},
    {"id": 2, "title": "CSS Tips for Beginners", "summary": "Boost your web designs with these easy CSS tips."},
    {"id": 3, "title": "Top 10 Programming Languages", "summary": "A rundown of the most popular programming languages in 2024."}
]

# Ensure all posts have the 'id' key
validated_posts = [post for post in posts if "id" in post]

@app.route('/')
def index():
    return render_template('blog.html', posts=validated_posts)

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/blog/<int:post_id>')
def blog_detail(post_id):
    post = next((p for p in validated_posts if p["id"] == post_id), None)
    if post is None:
        return "Post not found!", 404
    return render_template('blog.html', post=post)

if __name__ == '__main__':
    app.run(debug=True)


